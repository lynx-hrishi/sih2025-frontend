// import Student from './Student.jsx'
// import Student from "./Student.jsx";
// import LandingPage from "./College.jsx";
import LandingPage from "./newCollege.jsx";
// import EventPage from "./Events.jsx";

function App(){

  return (
    // <EventPage eventId={"68add58e71c2587eda206a48"}/>
    <LandingPage/>
  )
  // fetch("/products")
  // .then(res => {
  //   if (!res.ok) throw new Error("Network is Not Ok");
  //   return res.json();
  // })
  // .then(data => console.log(data))
  // .catch(err => console.log(err));
  // return(
  //   <>
  //   <h1>Hello</h1>
  //   <Student name="Hrishikesh" age={20} isStudent={true}></Student>
  //   </>
  // );
}

export default App