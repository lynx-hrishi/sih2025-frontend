import React, { useState, useRef, useEffect } from "react";
import LangLogo from "./assets/lang.svg";
import closeLogo from "./assets/close.svg";
import menuLogo from "./assets/menu.svg";

export default function College() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      from: "bot",
      text: "Hi, I'm AskBot! Feel free to ask me anything about this college.",
    },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef(null);

  // auto-scroll on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    if (input.trim() === "") return;

    const userMsg = { from: "user", text: input };
    setMessages((prev) => [...prev, userMsg]);

    const currentInput = input; // preserve before clearing
    setInput("");

    const payload = {
    query: input.trim(),
    context: messages
  }
  const sendData = new FormData();
  sendData.append("payload", JSON.stringify(payload));
//   payload.append("context", messages);

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      body: sendData
    });

      if (!response.body) {
        throw new Error("No response body");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let botMsg = { from: "bot", text: "" };

      // add empty bot message first
      setMessages((prev) => [...prev, botMsg]);

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });

        botMsg.text += chunk;

        // update the last bot message progressively
        setMessages((prev) => {
          const updated = [...prev];
          updated[updated.length - 1] = { ...botMsg };
          return updated;
        });
      }
    } catch (err) {
      console.error("Network error:", err);
      setMessages((prev) => [
        ...prev,
        { from: "bot", text: "⚠️ Sorry, something went wrong." },
      ]);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-white">
      {/* Navbar */}
      <header className="w-full shadow-md bg-white fixed top-0 z-20">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-blue-600 font-bold text-xl">
            🎓 MyCollege
          </div>
          <nav className="hidden md:flex gap-6 text-gray-700 font-medium">
            <a href="#about" className="hover:text-blue-600">
              About
            </a>
            <a href="#courses" className="hover:text-blue-600">
              Courses
            </a>
            <a href="#admissions" className="hover:text-blue-600">
              Admissions
            </a>
            <a href="#contact" className="hover:text-blue-600">
              Contact
            </a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="flex flex-col md:flex-row items-center justify-between text-center md:text-left px-6 mt-24 md:mt-32 max-w-7xl mx-auto">
        <div className="md:w-1/2">
          <h1 className="text-4xl md:text-6xl font-extrabold text-gray-800">
            Welcome to <span className="text-blue-600">MyCollege</span>
          </h1>
          <p className="mt-4 text-lg md:text-xl text-gray-600 max-w-xl">
            Shaping the future through excellence in education, innovation, and
            community.
          </p>
          <div className="mt-6 flex gap-4 justify-center md:justify-start">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg shadow-md">
              Apply Now
            </button>
            <button className="border border-gray-300 px-6 py-2 rounded-lg hover:bg-gray-100">
              Learn More
            </button>
          </div>
        </div>
        <div className="md:w-1/2 mt-8 md:mt-0 flex justify-center">
          <img
            src="https://d1gtq9mqg5x3oe.cloudfront.net/images/_articles/communications/releases/2023/08-august/princeton-review-2024/image-Folders-By-Ratio/promo/Gen-Campus_kp4_promo-4-660x371.jpg"
            // scr={`https://placehold.co?text=College`}
            alt="College campus"
            className="rounded-xl shadow-lg"
          /> 
        </div>
      </section>

       {/* Courses Section */}
       <section id="courses" className="max-w-7xl mx-auto mt-24 px-6">
         <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-8 text-center">
           Our Popular Courses
         </h2>
         <div className="grid md:grid-cols-3 gap-8">
           {["Engineering", "Business", "Arts"].map((course, idx) => (
            <div
              key={idx}
              className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-lg transition"
             >
              <img
                src={`https://placehold.co/400x250.png?text=${course}`}
                alt={course}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="font-bold text-lg text-gray-800">{course}</h3>
                <p className="text-gray-600 mt-2 text-sm">
                  Learn more about our {course} programs designed to prepare you for the future.
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

       {/* About Section */}
       <section id="about" className="max-w-6xl mx-auto mt-24 px-6">
         <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">About Us</h2>
         <p className="text-gray-600 leading-relaxed">
           MyCollege is committed to delivering world-class education, fostering innovation,
           and building leaders of tomorrow. With a legacy of excellence, we provide students
           with the tools they need to succeed in an ever-changing world.
         </p>
       </section>

      {/* Footer */}
      <footer className="mt-24 bg-gray-100 py-6 text-center text-gray-600 text-sm">
        © {new Date().getFullYear()} MyCollege. All Rights Reserved.
      </footer>

      {/* Floating Ask AI Button */}
      <button
        onClick={() => setIsChatOpen(true)}
        className="fixed bottom-6 right-6 bg-blue-600 text-white px-5 py-3 rounded-full shadow-lg font-semibold hover:bg-blue-700"
      >
        Ask AI
      </button>

      {/* Chat Popup */}
      {isChatOpen && (
        <div className="fixed bottom-20 right-6 w-80 h-96 bg-white shadow-xl rounded-lg flex flex-col overflow-hidden border">
          {/* Header */}
          <div className="bg-blue-600 text-white px-4 py-2 flex justify-between items-center">
            <span className="font-semibold flex relative">AskBot <img src={menuLogo} className="absolute left-57 p-1 rounded-sm cursor-pointer h-6 hover:border hover:border-blue-400" alt="Lang Logo" /></span>
            <button
              onClick={() => setIsChatOpen(false)}
              className="text-black hover:text-gray-200 cursor-pointer "
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="w-6 h-6 text-white hover:text-red-500 cursor-pointer"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-3 overflow-y-auto space-y-2 text-sm flex flex-col">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`p-2 rounded-lg max-w-[80%] ${
                  msg.from === "bot"
                    ? "bg-gray-100 text-gray-700 self-start"
                    : "bg-blue-600 text-white self-end"
                }`}
              >
                {msg.text}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="border-t flex items-center p-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 p-2 text-sm outline-none"
              onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            />
            <button
              onClick={sendMessage}
              className="bg-blue-600 text-white px-3 py-1 rounded-lg hover:bg-blue-700"
            >
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
