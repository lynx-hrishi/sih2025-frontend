import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(),     
    tailwindcss()
],
  server: {
    allowedHosts: ["4cd959b12113.ngrok-free.app"],
    proxy: {
      "/api": "http://localhost:8000",
      "/products": "http://localhost:3000",
      "/events": "http://localhost:3000"
    }
  }
})
